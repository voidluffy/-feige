﻿//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by uninst.rc
//
#define IDS_UNINSTCOMPLETE              12
#define IDS_TERMINATE                   13
#define IDS_CANTTERMINATE               14
#define IDS_REQUIREADMIN_TERM           15
#define IDS_REQUIREADMIN_PUBKEY         16
#define IDS_NOTCREATEFILE               17
#define IDS_START                       18
#define IDS_REGIPMSG                    19
#define RESETUP_EDIT                    100
#define SETUP_ICON                      104
#define UNINSTALL_DIALOG                149
#define DELPUBKEY_CHECK                 1152

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         30034
#define _APS_NEXT_CONTROL_VALUE         1153
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
