﻿/*static char *version_id = 
	"@(#)Copyright (C) H.Shirouzu 2011   version.h	Ver3.00"; */
/* ========================================================================
	Project  Name			: IP Messenger for Win32
	Module Name				: Version
	Create					: 2010-05-23(Sun)
	Update					: 2011-04-20(Wed)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef VERSION_H
#define VERSION_H

char *GetVersionStr(void);

#endif

